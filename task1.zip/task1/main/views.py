# Create your views here.

from django.shortcuts import render, redirect
from .forms import SignupForm
from .models import User

def signup(request):
    if request.method == "POST":
        form = SignupForm(request.POST, request.FILES)
        if form.is_valid():
            form.cleaned_data.pop("confirm_password")
            user = User.objects.create(**form.cleaned_data)
            return redirect("login")
    else:
        form = SignupForm()
    return render(request, "signup.html", {"form": form})

def login_view(request):
    error = ""
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        try:
            user = User.objects.get(username=username, password=password)
            request.session["user_id"] = user.id
            return redirect("dashboard")
        except User.DoesNotExist:
            error = "Invalid username or password"
    return render(request, "login.html", {"error": error})

def dashboard(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("login")
    user = User.objects.get(id=user_id)
    return render(request, "dashboard.html", {"user": user})

def logout_view(request):
    request.session.flush()
    return redirect("login")
